//#include <odroid_system.h>
#include <string.h>
#include <assert.h>

#include <xtl.h>

#include <SDL.h>

//HCF
#define ODROID_AUDIO_VOLUME_MIN 0

#define iAnchoVideo 320
#define iAltoVideo 240

//HCF
/**
#define INPUT_LEFT 0
#define INPUT_UP 1
#define INPUT_RIGHT 2
#define INPUT_DOWN 3 
#define INPUT_A 4 
#define INPUT_B 5 
#define INPUT_SELECT 6
#define INPUT_START 7
#define INPUT_VOLUME 8
#define INPUT_POWER 9
**/

#define NUM_BOTONES 20
#define BOTON_ARRIBA 0
#define BOTON_ABAJO 1
#define BOTON_IZQUIERDA 2
#define BOTON_DERECHA 3
#define BOTON_AA 4
#define BOTON_BB 5
#define BOTON_XX 6
#define BOTON_YY 7
#define BOTON_BLANCO 8
#define BOTON_NEGRO 9
#define BOTON_START 10
#define BOTON_BACK 11
#define BOTON_LTRIGGER 12
#define BOTON_RTRIGGER 13

short ashBotones[NUM_BOTONES];
Sint16 blackbutton;
Sint16 whitebutton;
Sint16 abutton; //A button
Sint16 bbutton;
Sint16 xbutton;
Sint16 ybutton;
Sint16 backbutton; //BACK button
Sint16 startbutton; //START button
Sint16 rstick; 
Sint16 dpad; //dpad
Sint16 ltrigger, rtrigger; //Trigger buttons
Sint16 joyx, joyy; //axes

//HCF Let's try to make it minimal
//#include "main.h"
#include "gw_lcd.h"
#include "gw_linker.h"
#include "gw_buttons.h"

//HCF
const unsigned char *ROM_DATA = NULL;
unsigned char ROM_ARRAY[622592];
unsigned int ROM_DATA_LENGTH;


/* TO move elsewhere */
//HCF Try to remove all this
//#include "stm32h7xx_hal.h"

#include "common.h"
#include "rom_manager.h"

/* G&W system support */
#include "gw_system.h"

//HCF
#include "../../../inc/odroid_input.h"

/* access to internals for debug purpose */
#include "sm510.h"

/* Uncomment to enable debug menu in overlay */
//#define GW_EMU_DEBUG_OVERLAY

#define ODROID_APPID_GW 6

/* Audio buffer length */
#define GW_AUDIO_BUFFER_LENGTH_DMA ((2 * GW_AUDIO_FREQ) / GW_REFRESH_RATE)


//HCF
SDL_Surface * surface, * mainSurface;
SDL_Joystick *joystickXB;

static odroid_gamepad_state_t joystick;

static unsigned char state_save_buffer[sizeof(gw_state_t)];

void odroid_input_read_gamepad(odroid_gamepad_state_t* out_state);


//HCF
//#define BUFFER_SIZE		0x8000   //AUDIO_BUFFER_LENGTH     //0x8000
#define BUFFER_SIZE		0x800000   //AUDIO_BUFFER_LENGTH     //0x8000
uint16* DACBuffer;
uint32 LeftFIFOHeadPtr, LeftFIFOTailPtr, RightFIFOHeadPtr, RightFIFOTailPtr;
SDL_AudioSpec desired;
void SDLSoundCallback(void* userdata, Uint8* buffer, int length);
//int GetCalculatedFrequency(void);
//XBOX
bool bAudioYaInicializado = 0;

//
// Reset the sound buffer FIFOs
//
void DACReset(void)
{
	LeftFIFOHeadPtr = LeftFIFOTailPtr = 0, RightFIFOHeadPtr = RightFIFOTailPtr = 1;
}

void DACInit(void)
{
	DACBuffer = (uint16*)malloc(BUFFER_SIZE * sizeof(uint16));

		//HCF TRICK
	//desired.freq = 32768;
	//desired.freq = 48000;
	//desired.freq = 44100;
	//desired.freq = 22050;
	desired.freq = 11025;		// SDL will do conversion on the fly, if it can't get the exact rate. Nice!
	//desired.freq = GetCalculatedFrequency();		// SDL will do conversion on the fly, if it can't get the exact rate. Nice!

	desired.format = AUDIO_S16SYS;
	//desired.format = AUDIO_S16SYS;					// This uses the native endian (for portability)...

	//HCF TRICKMONO
	desired.channels = 1;
	//desired.channels = 2;

	//desired.samples = 8192;
	//desired.samples = 4096;							// Let's try a 4K buffer (can always go lower)
	//HCF TRICK
	//desired.samples = (32768U / 128) ;   // 512;
	//desired.samples = 1024;							// Let's try a 4K buffer (can always go lower)
	//desired.samples = 2048;							// Let's try a 4K buffer (can always go lower)


	//desired.samples = 512;							// Let's try a 4K buffer (can always go lower)
	//desired.samples = (48000 / 50) ;   //48000 is the freq, 50 is hertzs
	//desired.samples = (48000 / 50) ;
	/////desired.samples = (11025 / 50);
	///////desired.samples = (11025 / 60);   //?????
	desired.samples = (11025 / 90);   //?????
	//desired.samples = (11025 / 50) * 3;
	//desired.samples = (11025 / 50) * 3.333333;
	//desired.samples = (11025 / 166.66666);
	//desired.samples = (11025 / 128);
	//desired.samples = (22050 / 50);
	desired.callback = SDLSoundCallback; 
	//sdl_callback;
	

	if (bAudioYaInicializado == 0)
	{
		if (SDL_OpenAudio(&desired, NULL) < 0)			// NULL means SDL guarantees what we want
		{
			exit(1);
		}
		bAudioYaInicializado = 1;
	}

	DACReset();
	SDL_PauseAudio(0);							// Start playback!
	
}

//
// Close down the SDL sound subsystem (?) (!)
//
void DACDone(void)
{
	SDL_PauseAudio(1);
	SDL_CloseAudio();
}

//
// SDL callback routine to fill audio buffer
//
// Note: The samples are packed in the buffer in 16 bit left/16 bit right pairs.
//
void SDLSoundCallback(void* userdata, Uint8* buffer, int length)
{
	//HCF for the optimization
	int iCopyAux, iCopyTotal;

	// Clear the buffer to silence, in case the DAC buffer is empty (or short)
	//HCF v1.0
	//memset(buffer, desired.silence, length);

//WriteLog("DAC: Inside callback...\n");
	if (LeftFIFOHeadPtr != LeftFIFOTailPtr)
	{
		//WriteLog("DAC: About to write some data!\n");
		int numLeftSamplesReady
			= (LeftFIFOTailPtr + (LeftFIFOTailPtr < LeftFIFOHeadPtr ? BUFFER_SIZE : 0))
			- LeftFIFOHeadPtr;
	/*	
		int numRightSamplesReady
			= (RightFIFOTailPtr + (RightFIFOTailPtr < RightFIFOHeadPtr ? BUFFER_SIZE : 0))
			- RightFIFOHeadPtr;
		*/

		int numSamplesReady
			= numLeftSamplesReady;//Hmm. * 2;
		

		
//The numbers look good--it's just that the DSP can't get enough samples in the DAC buffer!
//WriteLog("DAC: Left/RightFIFOHeadPtr: %u/%u, Left/RightFIFOTailPtr: %u/%u\n", LeftFIFOHeadPtr, RightFIFOHeadPtr, LeftFIFOTailPtr, RightFIFOTailPtr);
//WriteLog("     numLeft/RightSamplesReady: %i/%i, numSamplesReady: %i, length of buffer: %i\n", numLeftSamplesReady, numRightSamplesReady, numSamplesReady, length);

		/**
		if (numSamplesReady > length)
			numSamplesReady = length;
		**/
		
		if (numSamplesReady > length / 2)	// length / 2 because we're comparing 16-bit lengths
			numSamplesReady = length / 2;
		
		//else
		//	WriteLog("     Not enough samples to fill the buffer (short by %u L/R samples)...\n", (length / 2) - numSamplesReady);
		//WriteLog("DAC: %u samples ready.\n", numSamplesReady);


			//HCF This IS a real optimization!!
			//HCF v1.0: Aqui se puede asignar puntero en vez de copiar?!
			//HCF v1.0
			/////buffer = (Uint8*)&DACBuffer[LeftFIFOHeadPtr];

			//HCF v1.0 Antes se copiaba asi:
			/****/
			//HCF: Esta comprobado que esto es mas rapido!!!
		iCopyAux = BUFFER_SIZE - (LeftFIFOHeadPtr + numSamplesReady);
		if (iCopyAux >= 0)
		{
			
			memcpy(buffer, &DACBuffer[LeftFIFOHeadPtr], numSamplesReady * sizeof(uint16));
			//memcpy(buffer, &audiobuffer_dma[LeftFIFOHeadPtr], numSamplesReady * sizeof(uint16));
		}
		else
		{
			//iCopyAux is negative
			iCopyTotal = numSamplesReady + iCopyAux;

			//memcpy(buffer, &audiobuffer_dma[LeftFIFOHeadPtr], iCopyTotal * sizeof(uint16));
			//memcpy(&buffer[iCopyTotal * sizeof(uint16)], &audiobuffer_dma[0], (numSamplesReady - iCopyTotal) * sizeof(uint16));
			memcpy(buffer, &DACBuffer[LeftFIFOHeadPtr], iCopyTotal * sizeof(uint16));
			memcpy(&buffer[iCopyTotal * sizeof(uint16)], &DACBuffer[0], (numSamplesReady - iCopyTotal) * sizeof(uint16));

		}
		/****/
		//HCF v1.0 Antes se copiaba asi
		//HCF This is a real optimization!!


	/********************

			// Actually, it's a bit more involved than this, but this is the general idea:
	//		memcpy(buffer, DACBuffer, length);
			for(int i=0; i<numSamplesReady; i++)
				// Could also use (as long as BUFFER_SIZE is a multiple of 2):
				((uint16 *)buffer)[i] = DACBuffer[(LeftFIFOHeadPtr + i) % BUFFER_SIZE];
	//			buffer[i] = DACBuffer[(LeftFIFOHeadPtr + i) & (BUFFER_SIZE - 1)];
	**********************/
		LeftFIFOHeadPtr = (LeftFIFOHeadPtr + numSamplesReady) % BUFFER_SIZE;
		//RightFIFOHeadPtr = (RightFIFOHeadPtr + numSamplesReady) % BUFFER_SIZE;
		
		
		// Could also use (as long as BUFFER_SIZE is a multiple of 2):
//		LeftFIFOHeadPtr = (LeftFIFOHeadPtr + (numSamplesReady)) & (BUFFER_SIZE - 1);
//		RightFIFOHeadPtr = (RightFIFOHeadPtr + (numSamplesReady)) & (BUFFER_SIZE - 1);
//WriteLog("  -> Left/RightFIFOHeadPtr: %u/%u, Left/RightFIFOTailPtr: %u/%u\n", LeftFIFOHeadPtr, RightFIFOHeadPtr, LeftFIFOTailPtr, RightFIFOTailPtr);
	}
	//Hmm. Seems that the SDL buffer isn't being starved by the DAC buffer...
	//	else
	//		WriteLog("DAC: Silence...!\n");
}

//
// Calculate the frequency of SCLK * 32 using the divider
//
/**
int GetCalculatedFrequency(void)
{
	extern bool hardwareTypeNTSC;
	int systemClockFrequency = (hardwareTypeNTSC ? RISC_CLOCK_RATE_NTSC : RISC_CLOCK_RATE_PAL);

	// We divide by 32 here in order to find the frequency of 32 SCLKs in a row (transferring
	// 16 bits of left data + 16 bits of right data = 32 bits, 1 SCLK = 1 bit transferred).
	return systemClockFrequency / (32 * (2 * (SCLKFrequencyDivider + 1)));
}
**/

void vdXboxPlaySound(uint8_t *pucBuffer)
{
	//HCF TODO!!!!
	/**
	int iii = 0;
	int jjj = 0;
	while (iii < GW_AUDIO_BUFFER_LENGTH)
	{
		DACBuffer[LeftFIFOHeadPtr + iii] = audiobuffer_dma[jjj];
		iii++;
		jjj += 2;

	}
	**/

	memcpy(&DACBuffer[LeftFIFOHeadPtr], audiobuffer_dma, GW_AUDIO_BUFFER_LENGTH);

	LeftFIFOTailPtr = (LeftFIFOTailPtr + GW_AUDIO_BUFFER_LENGTH / 2 ) % BUFFER_SIZE;
	
	//RightFIFOTailPtr = (RightFIFOTailPtr + GW_AUDIO_BUFFER_LENGTH / 2 ) % BUFFER_SIZE;

	/*
	LeftFIFOTailPtr = (LeftFIFOTailPtr + GW_AUDIO_BUFFER_LENGTH / 2)% AUDIO_BUFFER_LENGTH;
	RightFIFOTailPtr = (RightFIFOTailPtr + GW_AUDIO_BUFFER_LENGTH / 2) % AUDIO_BUFFER_LENGTH;
	*/
}

void vdRellenaBotones(void)
{
	
	SDL_PumpEvents();
	SDL_JoystickUpdate(); //manual refresh of the gamepad(s)
	
	joyx = SDL_JoystickGetAxis(joystickXB, 0);
	joyy = SDL_JoystickGetAxis(joystickXB, 1);
	dpad = SDL_JoystickGetHat(joystickXB, 0);
	blackbutton = SDL_JoystickGetButton(joystickXB, 4); //Black Button
	whitebutton = SDL_JoystickGetButton(joystickXB, 5); //White Button, comprobarlo!!
	abutton = SDL_JoystickGetButton(joystickXB, 0); //Get A-Button(0)
	bbutton = SDL_JoystickGetButton(joystickXB, 1);
	backbutton = SDL_JoystickGetButton(joystickXB, 9); //Get BACK-Button(9)
	rstick = SDL_JoystickGetButton(joystickXB,11);
	ltrigger = SDL_JoystickGetButton(joystickXB,6);
	rtrigger = SDL_JoystickGetButton(joystickXB,7);
	xbutton = SDL_JoystickGetButton(joystickXB,2);
	ybutton = SDL_JoystickGetButton(joystickXB,3);
	startbutton = SDL_JoystickGetButton(joystickXB,8);

	if(startbutton)
	{
	    ashBotones[BOTON_START] = 1;
	}
	else
	{
	    ashBotones[BOTON_START] = 0;
	}
	if(ltrigger)
	{
	    ashBotones[BOTON_LTRIGGER] = 1;
	}
	else
	{
	    ashBotones[BOTON_LTRIGGER] = 0;
	}
	if(rtrigger)
	{
	    ashBotones[BOTON_RTRIGGER] = 1;
	}
	else
	{
	    ashBotones[BOTON_RTRIGGER] = 0;
	}
	if(backbutton)
	{
	    ashBotones[BOTON_BACK] = 1;
	}
	else
	{
	    ashBotones[BOTON_BACK] = 0;
	}
	if(abutton)
	{
	    ashBotones[BOTON_AA] = 1;
	}
	else
	{
	    ashBotones[BOTON_AA] = 0;
	}
	if(blackbutton)
	{
	    ashBotones[BOTON_NEGRO] = 1;
	}
	else
	{
	    ashBotones[BOTON_NEGRO] = 0;
	}
	if(whitebutton)
	{
	    ashBotones[BOTON_BLANCO] = 1;
	}
	else
	{
	    ashBotones[BOTON_BLANCO] = 0;
	}
	if(bbutton)
	{
	    ashBotones[BOTON_BB] = 1;
	}
	else
	{
	    ashBotones[BOTON_BB] = 0;
	}
	if(ybutton)
	{
	    ashBotones[BOTON_YY] = 1;
	}
	else
	{
	    ashBotones[BOTON_YY] = 0;
	}
	if(xbutton)
	{
	    ashBotones[BOTON_XX] = 1;
	}
	else
	{
	    ashBotones[BOTON_XX] = 0;
	}
	
	if(dpad & SDL_HAT_UP)
	{
		ashBotones[BOTON_ARRIBA] = 1;
	}
	else
	{
	    ashBotones[BOTON_ARRIBA] = 0;
	}
	if(dpad & SDL_HAT_DOWN)
	{
		ashBotones[BOTON_ABAJO] = 1;
	}
	else
	{
	    ashBotones[BOTON_ABAJO] = 0;
	}
	if(dpad & SDL_HAT_LEFT)
	{
		ashBotones[BOTON_IZQUIERDA] = 1;
	}
	else
	{
	    ashBotones[BOTON_IZQUIERDA] = 0;
	}
	if(dpad & SDL_HAT_RIGHT)
	{
		ashBotones[BOTON_DERECHA] = 1;
	}
	else
	{
	    ashBotones[BOTON_DERECHA] = 0;
	}
	
}

void XBOX_input()
{
	vdRellenaBotones();

}



static bool gw_system_SaveState(char *pathName)
{
    printf("Saving state...\n");

    memset(state_save_buffer, '\x00', sizeof(state_save_buffer));
    gw_state_save(state_save_buffer);
    store_save(ACTIVE_FILE->save_address, state_save_buffer, sizeof(state_save_buffer));
    printf("Saving state done!\n");
    return false;
}

static bool gw_system_LoadState(char *pathName)
{
    //printf("Loading state...\n");
    //gw_state_load(ACTIVE_FILE->save_address);
    //printf("Loading state done!\n");
    return true;
}

/* callback to get buttons state */
unsigned int gw_get_buttons()
{
	vdRellenaBotones();

	//Return to rom list
	if( ashBotones[BOTON_START] && ashBotones[BOTON_BACK] )
		XLaunchNewImage( "D:\\default.xbe", NULL);

    unsigned int hw_buttons = 0;
    hw_buttons |= ashBotones[BOTON_IZQUIERDA];
    hw_buttons |= ashBotones[BOTON_ARRIBA] << 1;
    hw_buttons |= ashBotones[BOTON_DERECHA] << 2;
    hw_buttons |= ashBotones[BOTON_ABAJO] << 3;
    hw_buttons |= ashBotones[BOTON_AA] << 4;
    hw_buttons |= ashBotones[BOTON_BB] << 5;
    hw_buttons |= ashBotones[BOTON_BACK] << 6;
    hw_buttons |= ashBotones[BOTON_START] << 7;
    hw_buttons |= ashBotones[BOTON_XX] << 8;
    hw_buttons |= ashBotones[BOTON_YY] << 9;
    
	
	//FUERZA START 1 vez... y vA!!!
	//NI SIQUIERA CON ESTO FUNCIONABAAAA!!!
	/**
	static int cap = 0;
	if (cap < 100)
	{
		cap++;
		return 64; // return 255;
	}
	**/
	//FUERZA START 1 vez... y vA!!!


	return hw_buttons;
}

static void gw_sound_init()
{

    /* init emulator sound system with shared audio buffer */
    gw_system_sound_init();

    /* clear DMA audio buffer */
    memset(audiobuffer_dma, 0, sizeof(audiobuffer_dma));

    /* Start SAI DMA */
	//HCF
	//vdXboxPlaySound(uint8_t *)audiobuffer_dma, GW_AUDIO_BUFFER_LENGTH_DMA);
    //HAL_SAI_Transmit_DMA(&hsai_BlockA1, (uint8_t *)audiobuffer_dma, GW_AUDIO_BUFFER_LENGTH_DMA);
}

static void gw_sound_submit()
{

	//HCF
    uint8_t volume = 7;   //odroid_audio_volume_get();
    int16_t factor = volume_tbl[volume];

    /** Enables the following code to track audio rendering issues **/
    /*
    if (gw_audio_buffer_idx < GW_AUDIO_BUFFER_LENGTH) {
        printf("audio underflow:%u < %u \n",gw_audio_buffer_idx , GW_AUDIO_BUFFER_LENGTH);
        assert(0);
    }

    if (gw_audio_buffer_idx > (GW_AUDIO_BUFFER_LENGTH +12) ) {
        printf("audio oveflow:%u < %u \n",gw_audio_buffer_idx , GW_AUDIO_BUFFER_LENGTH);
        assert(0);
    }
    */

    size_t offset = (dma_state == DMA_TRANSFER_STATE_HF) ? 0 : GW_AUDIO_BUFFER_LENGTH;

    if (audio_mute || volume == ODROID_AUDIO_VOLUME_MIN)
    {
        for (int i = 0; i < GW_AUDIO_BUFFER_LENGTH; i++)
        {
            audiobuffer_dma[i + offset] = 0;
        }
    }
    else
    {
        for (int i = 0; i < GW_AUDIO_BUFFER_LENGTH; i++)
        {
            audiobuffer_dma[i + offset] = (factor) * (gw_audio_buffer[i] << 4);
        }
    }

    gw_audio_buffer_copied = true;

	vdXboxPlaySound((uint8_t *)audiobuffer_dma);
}

/************************ Debug function in overlay START *******************************/

/* performance monitoring */
/* Emulator loop monitoring
    ( unit is 1/systemcoreclock 1/280MHz )
    loop_cycles
        -measured duration of the loop.
    proc_cycles
        - estimated duration of emulated CPU for a bunch of emulated system clock.
    blit_cycles
        - estimated duration of graphics rendering.
    end_cycles
        - estimated duration of overall processing.
    */

static unsigned int loop_cycles = 1, end_cycles = 1, proc_cycles = 1, blit_cycles = 1;

/* DWT counter used to measure time execution */
volatile unsigned int *DWT_CONTROL = (unsigned int *)0xE0001000;

//HCF
volatile unsigned int NUM_DWT_CYCCNT;
volatile unsigned int* DWT_CYCCNT; // = (unsigned int*)0xE0001004;
//volatile unsigned int *DWT_CYCCNT = (unsigned int *)0xE0001004;

volatile unsigned int *DEMCR = (unsigned int *)0xE000EDFC;
volatile unsigned int *LAR = (unsigned int *)0xE0001FB0; // <-- lock access register

#define get_dwt_cycles() *DWT_CYCCNT
#define clear_dwt_cycles() *DWT_CYCCNT = 0

#ifdef GW_EMU_DEBUG_OVERLAY
static void enable_dwt_cycles()
{

    /* Use DWT cycle counter to get precision time elapsed during loop.
    The DWT cycle counter is cleared on every loop
    it may crash if the DWT is used during trace profiling */

    *DEMCR = *DEMCR | 0x01000000;    // enable trace
    *LAR = 0xC5ACCE55;               // <-- added unlock access to DWT (ITM, etc.)registers
    *DWT_CYCCNT = 0;                 // clear DWT cycle counter
    *DWT_CONTROL = *DWT_CONTROL | 1; // enable DWT cycle counter
}
#endif

static void gw_debug_bar()
{

#ifdef GW_EMU_DEBUG_OVERLAY
    static unsigned int loop_duration_us = 1, end_duration_us = 1, proc_duration_us = 1, blit_duration_us = 1;
    static const unsigned int SYSTEM_CORE_CLOCK_MHZ = 280;

    static bool debug_init_done = false;

    if (!debug_init_done)
    {
        enable_dwt_cycles();
        debug_init_done = true;
    }

    static unsigned int overflow_count = 0;
    static unsigned int busy_percent = 0;

    char debugMsg[120];

    proc_duration_us = proc_cycles / SYSTEM_CORE_CLOCK_MHZ;
    blit_duration_us = blit_cycles / SYSTEM_CORE_CLOCK_MHZ;
    end_duration_us = end_cycles / SYSTEM_CORE_CLOCK_MHZ;
    loop_duration_us = loop_cycles / SYSTEM_CORE_CLOCK_MHZ;

    busy_percent = 100 * (proc_duration_us + blit_duration_us) / loop_duration_us;

    if (end_duration_us > 1000000 / GW_REFRESH_RATE)
        overflow_count++;

    if (m_halt != 0)
        sprintf(debugMsg, "%04dus EMU:%04dus FX:%04dus %d%%+%d HALT", loop_duration_us, proc_duration_us, blit_duration_us, busy_percent, overflow_count);
    else
        sprintf(debugMsg, "%04dus EMU:%04dus FX:%04dus %d%%+%d", loop_duration_us, proc_duration_us, blit_duration_us, busy_percent, overflow_count);

    odroid_overlay_draw_text(0, 0, GW_SCREEN_WIDTH, debugMsg, C_GW_YELLOW, C_GW_RED);

#endif
}
/************************ Debug function in overlay END ********************************/

/* Main */
//HCF
int main(int argc, char** argv)
//int app_main_gw(uint8_t load_state)
{
	//Para tener Z:
	#define FILE_DATA_INI "Z:\\rom.ini"  //Z:
	XMountUtilityDrive(false);
	FILE *fdini;
	fdini = fopen(FILE_DATA_INI, "r");
	#define TAM_FICHERO 128 
	char achFicheroElegido[TAM_FICHERO];
	char utf8_tmpargv[TAM_FICHERO];
	memset(achFicheroElegido, 0x00, TAM_FICHERO);
	memset(utf8_tmpargv, 0x00, TAM_FICHERO);
	if(fdini != NULL)
	{
		//Selected rom name (useful for savestate filename)
		//fprintf(fdini, "%s\n", achFicheroElegidoAdornado ) ;
		fgets( utf8_tmpargv, TAM_FICHERO, fdini );
		strncpy( achFicheroElegido, utf8_tmpargv, strlen(utf8_tmpargv)-1) ;
		//fscanf(fdini, "%s", achFicheroElegido);
		fclose(fdini);
	}


	DWT_CYCCNT = &NUM_DWT_CYCCNT;

	common_emu_state.frame_time_10us = (uint16_t)(100000 / 60 + 0.5f);  // Reasonable default of 60FPS if not explicitly configured.

	//HCF FALTA ASIGNAR ESTOS VALORES (ya declarados fuera)
	FILE *fd;
	int iii = 0;
	//fd = fopen("D:\\bride.hgw","rb");
	//fd = fopen("D:\\fire.hgw","rb");
	//fd = fopen("D:\\bombs.hgw","rb");
	//fd = fopen("D:\\Donkey Kong II.hgw","rb");
	fd = fopen(achFicheroElegido,"rb");
	while(!feof(fd))
	{
		ROM_ARRAY[iii] = fgetc(fd);
		iii++;
	}
	fclose(fd);
	ROM_DATA = &ROM_ARRAY[0];
	ROM_DATA_LENGTH = iii - 1;
	/**
	const unsigned char *ROM_DATA = NULL;
	unsigned char ROM_ARRAY[622592];
	unsigned int ROM_DATA_LENGTH;
	**/

	unsigned int mainSurfaceFlags = SDL_SWSURFACE | SDL_FULLSCREEN;;

	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK |SDL_INIT_AUDIO | SDL_INIT_TIMER | SDL_INIT_NOPARACHUTE) < 0)
	{
		exit(1);
	}

	SDL_ShowCursor(0);
	mainSurface = SDL_SetVideoMode(iAnchoVideo, iAltoVideo, 16, mainSurfaceFlags);
	joystickXB = 0;

	//Init Input
	do
	{
		joystickXB = SDL_JoystickOpen(0);
		if(joystickXB == 0)
		{
			SDL_Delay(500);
		}

	}while( joystickXB == 0 );
   
	
	
    //odroid_system_init(ODROID_APPID_GW, GW_AUDIO_FREQ);
    //odroid_system_emu_init(&gw_system_LoadState, &gw_system_SaveState, NULL);
    
	//HCF
	//rg_app_desc_t *app = odroid_system_get_app();

    // const int frameTime = get_frame_time(GW_REFRESH_RATE);

    common_emu_state.frame_time_10us = (uint16_t)(100000 / GW_REFRESH_RATE + 0.5f);

    /*** load ROM  */
    bool rom_status = gw_system_romload();

	//HCF
    //if (!rom_status)
      //  odroid_system_switch_app(0);

    /*** Clear audio buffer */
    gw_sound_init();
    printf("Sound initialized\n");

    /*** Configure the emulated system */
    gw_system_config();
    printf("G&W configured\n");

    /*** Start and Reset the emulated system */
    gw_system_start();
    printf("G&W start\n");

    gw_system_reset();
    printf("G&W reset\n");

    /*** Main emulator loop */
    printf("Main emulator loop start\n");

    /* check if we to have to load state */
    //if (load_state != 0)
      //  gw_system_LoadState(NULL);

    clear_dwt_cycles();

	DACInit();

	#define TIME_PER_FRAME 6   //17
	unsigned long timeStart;
	unsigned long timeFrame;

    while (true)
    {
		timeStart = SDL_GetTicks();

        /* clear DWT counter used to monitor performances */
        clear_dwt_cycles();

        //wdog_refresh();
        
		//XBOX_input();
		odroid_input_read_gamepad(&joystick);
       
		//HCF
		//odroid_dialog_choice_t options[] = {
          //  ODROID_DIALOG_CHOICE_LAST
        //};
        
		//HCF Para pausar juego y opciones
		common_emu_input_loop(&joystick);
		//common_emu_input_loop(&joystick, options);

        bool drawFrame = common_emu_frame_loop();

        /* Emulate and Blit */
        // Call the emulator function with number of clock cycles
        // to execute on the emulated device
        gw_system_run(GW_SYSTEM_CYCLES);

        /* get how many cycles have been spent in the emulator */
        proc_cycles = get_dwt_cycles();

        /* update the screen only if there is no pending frame to render */
        
		//#define HCF_FRAMESKIP 3  //HCF Too fast!!
		#define HCF_FRAMESKIP 2  //HCF Too fast but needed because we still need to add sound
		//#define HCF_FRAMESKIP 1  
		static int frameskip = 0;

		//HCF
		if(!frameskip)
		//if(1)
		//if (drawFrame)
		//if (!is_lcd_swap_pending() && drawFrame)
        {
			frameskip++;
			
			//HCF
			gw_system_blit((unsigned short*)mainSurface->pixels);
            //gw_system_blit((unsigned short*)lcd_get_active_buffer());
            
			//HCF
			//gw_debug_bar();
            common_ingame_overlay();

			//HCF
			SDL_Flip(mainSurface);
            //lcd_swap();

            /* get how many cycles have been spent in graphics rendering */
            blit_cycles = get_dwt_cycles() - proc_cycles;
        }
		else
		{
			if(frameskip >= HCF_FRAMESKIP)
				frameskip = 0;
			else
				frameskip++;
		}
        /****************************************************************************/

        /* copy audio samples for DMA */
        if (drawFrame) {
            gw_sound_submit();
        }

        /* get how many cycles have been spent to process everything */
        end_cycles = get_dwt_cycles();

        if(!common_emu_state.skip_frames)
        {
            for(uint8_t p = 0; p < common_emu_state.pause_frames + 1; p++) {
                static dma_transfer_state_t last_dma_state = DMA_TRANSFER_STATE_HF;
                //!!!!!!!!
				/***
				while (dma_state == last_dma_state) {
                    #ifdef GW_EMU_DEBUG_OVERLAY
                    __NOP();
                    #else
                    cpumon_sleep();
                    #endif
                }
				***/
                last_dma_state = dma_state;
            }
        }

        /* get how cycles have been spent inside this loop */
        loop_cycles = get_dwt_cycles();

		timeFrame = SDL_GetTicks() - timeStart;
		if (timeFrame < TIME_PER_FRAME)
			SDL_Delay( TIME_PER_FRAME - timeFrame );

    } // end of loop
}
