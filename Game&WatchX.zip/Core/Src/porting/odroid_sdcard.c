#include "odroid_system.h"
#include "odroid_sdcard.h"


int odroid_sdcard_read_file(const char* path, void* buf, size_t buf_size)
{
    // STUB
    return 0;
}
