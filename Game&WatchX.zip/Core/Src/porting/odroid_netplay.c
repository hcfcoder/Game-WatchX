#include "odroid_system.h"
#include "odroid_netplay.h"

void odroid_netplay_sync(void *data_in, void *data_out, uint8_t data_len)
{
}


netplay_mode_t odroid_netplay_mode()
{
    return NETPLAY_MODE_NONE;
}


netplay_status_t odroid_netplay_status()
{
    return NETPLAY_MODE_NONE;
}
