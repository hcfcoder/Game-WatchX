#pragma once

unsigned int crc32_le(unsigned int crc, unsigned char const * buf,unsigned int len);
