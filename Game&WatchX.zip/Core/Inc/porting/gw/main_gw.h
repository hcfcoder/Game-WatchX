#pragma once

int app_main_gw(uint8_t load_state);
