#pragma once

int app_main_pce(uint8_t load_state, uint8_t start_paused);
