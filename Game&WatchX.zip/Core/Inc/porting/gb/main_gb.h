#pragma once

void app_main_gb(uint8_t load_state, uint8_t start_paused);
