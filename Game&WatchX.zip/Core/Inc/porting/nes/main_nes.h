#pragma once

int app_main_nes(uint8_t load_state, uint8_t start_paused);
