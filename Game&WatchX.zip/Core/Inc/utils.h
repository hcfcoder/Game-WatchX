#pragma once
#ifndef UTILS_H
#define UTILS_H

#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))

#endif // UTILS_H
