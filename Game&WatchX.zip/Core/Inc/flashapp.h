#pragma once

void flashapp_main(void);
