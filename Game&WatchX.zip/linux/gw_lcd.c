#include "gw_lcd.h"

uint8_t emulator_framebuffer[(256 + 8 + 8) * 240];
