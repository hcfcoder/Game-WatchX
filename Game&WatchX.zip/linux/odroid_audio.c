#include "odroid_system.h"
#include "odroid_audio.h"

void odroid_audio_submit(short* stereoAudioBuffer, int frameCount)
{
}
