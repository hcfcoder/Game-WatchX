#pragma once

extern const unsigned char ROM_DATA[];
extern unsigned int ROM_DATA_LENGTH;
extern const char *ROM_EXT;
