#pragma once

//#include <stdint.h>
typedef unsigned char uint8_t;

extern uint8_t emulator_framebuffer[(256 + 8 + 8) * 240];

